const { Account } = require("xrpl-secret-numbers");
const account = new Account(
  "399150 474506 009147 088773 432160 282843 253738 605430"
);
console.log(account);
